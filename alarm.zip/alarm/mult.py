import threading
import time
import datetime

exitFlag = 0
datetime.datetime.now().time()


class myThread (threading.Thread):
    def __init__(self, threadno,name, timr):
        threading.Thread.__init__(self)
        self.threadno = threadno
        self.name = name
        self.timr = timr
    def run(self):
        print "Starting alarm" + self.name
        print_time(self.name, self.timr)
        

def print_time(threadName,tim):
    tim=tim.split(":")
    while 1:
        l=str(datetime.datetime.now().time()).split(":")

        if l[0]==tim[0] and l[1]==tim[1]:
            print datetime.datetime.now().time()
            execfile('adi.py')
            # execfile('adi.py')
            # execfile('adi.py')
            break


thread_list=[0 for i in range( 1000)]
i=0
while 1:
    print "Enter the date and time of alarm in 24 hr format"
    n=raw_input()
    thread_list[i]=myThread(i,"Thread-"+str(i),str(n))
    thread_list[i].start()
    i+=1


    