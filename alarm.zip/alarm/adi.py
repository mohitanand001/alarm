import vlc
a = vlc.MediaPlayer("/home/mohit001/alarm/aud1.mp3")
cnt=1
while cnt<=5:
	a = vlc.MediaPlayer("/home/mohit001/alarm/aud1.mp3")

	cnt+=1
	i=1
	while 1:
		i+=1
		a.play()
		if(i==2**21):
			break

print cnt